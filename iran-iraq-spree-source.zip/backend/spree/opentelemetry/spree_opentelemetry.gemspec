# encoding: UTF-8

require_relative '../core/lib/spree/core/version.rb'

Gem::Specification.new do |s|
  s.platform    = Gem::Platform::RUBY
  s.name        = 'spree_opentelemetry'
  s.version     = Spree.version
  s.authors     = ['Vendo Connect Inc.', 'Vendo Sp. z o.o.']
  s.email       = 'hello@spreecommerce.org'
  s.summary     = 'OpenTelemetry instrumentation for Spree eCommerce platform'
  s.description = 'Distributed tracing for Spree — boots the OpenTelemetry SDK from standard OTEL_* environment variables and turns Spree workflow, event, webhook and payment-gateway instrumentation into spans'
  s.homepage    = 'https://spreecommerce.org'
  s.license     = 'MIT'

  s.metadata = {
    "bug_tracker_uri"   => "https://github.com/spree/spree/issues",
    "changelog_uri"     => "https://github.com/spree/spree/releases/tag/v#{s.version}",
    "documentation_uri" => "https://docs.spreecommerce.org/",
    "source_code_uri"   => "https://github.com/spree/spree/tree/v#{s.version}",
  }

  s.required_ruby_version = '>= 3.2'

  s.files        = Dir["{app,config,db,lib,vendor}/**/*", "Rakefile", "LICENSE", "README.md"].reject { |f| f.match(/^spec/) && !f.match(/^spec\/fixtures/) }
  s.require_path = 'lib'

  s.add_dependency 'spree_core', s.version

  s.add_dependency 'opentelemetry-sdk', '~> 1.0'
  s.add_dependency 'opentelemetry-exporter-otlp', '~> 0.26'
  s.add_dependency 'opentelemetry-instrumentation-rack'
  s.add_dependency 'opentelemetry-instrumentation-action_pack'
  s.add_dependency 'opentelemetry-instrumentation-action_mailer'
  s.add_dependency 'opentelemetry-instrumentation-active_record'
  s.add_dependency 'opentelemetry-instrumentation-active_support'
  s.add_dependency 'opentelemetry-instrumentation-active_job'
  s.add_dependency 'opentelemetry-instrumentation-concurrent_ruby'
  s.add_dependency 'opentelemetry-instrumentation-net_http'
end
