# encoding: UTF-8

require_relative 'lib/spree/core/version.rb'

Gem::Specification.new do |s|
  s.platform    = Gem::Platform::RUBY
  s.name        = 'spree_core'
  s.version     = Spree.version
  s.authors     = ['Sean Schofield', 'Spark Solutions Sp. z o.o.', 'Vendo Connect Inc.']
  s.email       = 'hello@spreecommerce.org'
  s.summary     = 'Spree Core business logic code'
  s.description = 'Spree Models, Services, Workflows and background jobs'
  s.homepage    = 'https://spreecommerce.org'
  s.license     = 'BSD-3-Clause'

  s.metadata = {
    "bug_tracker_uri"   => "https://github.com/spree/spree/issues",
    "changelog_uri"     => "https://github.com/spree/spree/releases/tag/v#{s.version}",
    "documentation_uri" => "https://docs.spreecommerce.org/",
    "source_code_uri"   => "https://github.com/spree/spree/tree/v#{s.version}",
  }

  s.required_ruby_version     = '>= 3.2'
  s.required_rubygems_version = '>= 1.8.23'

  s.files        = Dir["{app,config,db,lib}/**/*", "spec/fixtures/**/*", "Rakefile", "LICENSE", "README.md"].reject { |f| f.match(/^spec/) && !f.match(/^spec\/fixtures/) }
  s.require_path = 'lib'

  # Only used by the spec that replays the pre-6.0 seeded state list and fails
  # if any code it produced stops resolving through Spree::IsoData.
  s.add_development_dependency 'i18n-tasks'

  s.add_dependency 'rails', '>= 8.1', '< 8.2'


  s.add_dependency 'acts_as_list', '>= 0.8'
  s.add_dependency 'acts-as-taggable-on'
  s.add_dependency 'awesome_nested_set', '~> 3.3', '>= 3.3.1'
  s.add_dependency 'benchmark' # needed for ruby 4.0 and benchmark gem
  s.add_dependency 'cancancan', '~> 3.2'
  s.add_dependency 'countries'
  s.add_dependency 'friendly_id', '~> 5.2', '>= 5.2.1'
  s.add_dependency 'geocoder'
  s.add_dependency 'highline', '>= 2', '< 4' # Necessary for the install generator
  # json 3 removed the positional options hash, which ActiveSupport::JSON.decode
  # still passes (`::JSON.parse(json, options)`). Rolling a transaction back
  # restores JSON attributes through that path, so on json 3 any rollback
  # touching a JSON column raises ArgumentError. Rails' bug, not ours — unpin
  # once activesupport passes those options as keywords.
  s.add_dependency 'json', '< 3'
  s.add_dependency 'jwt', '~> 3.1'
  s.add_dependency 'money', '~> 6.13'
  s.add_dependency 'monetize', '~> 1.9'
  s.add_dependency 'name_of_person', '~> 1.1'
  s.add_dependency 'nokogiri', '~> 1.18'
  s.add_dependency 'ostruct'
  s.add_dependency 'paranoia', '>= 2.4'
  s.add_dependency 'loofah', '~> 2.21'
  s.add_dependency 'rails-html-sanitizer', '~> 1.6'
  s.add_dependency 'ransack', '>= 4.1'
  s.add_dependency 'request_store', '~> 1.5'
  s.add_dependency 'rexml'

  s.add_dependency 'stringex'
  s.add_dependency 'tracking_number'
  s.add_dependency 'validates_zipcode'
  s.add_dependency 'valvat', '~> 2.0'
  s.add_dependency 'image_processing', '~> 1.2'
  s.add_dependency 'active_storage_validations', '>= 1.3', '< 4'
  s.add_dependency 'mobility', '~> 1.3', '>= 1.3.2'
  s.add_dependency 'mobility-ransack', '~> 1.2'
  s.add_dependency 'friendly_id-mobility', '~> 1.0'
  s.add_dependency 'wannabe_bool'
  s.add_dependency 'safely_block', '>= 0.4', '< 2.0'
  s.add_dependency 'phonelib', '~> 0.10'
  s.add_dependency 'ar_lazy_preload', '~> 2.0'
  s.add_dependency 'bcrypt', '~> 3.1'
  s.add_dependency 'sqids', '~> 0.2'
  s.add_dependency 'ssrf_filter', '~> 1.0'
  s.add_dependency 'pagy', '>= 43.3'
end
