require_relative 'dependencies_helper'

module Spree
  module Core
    class Dependencies
      INJECTION_POINTS_WITH_DEFAULTS = {
        # ability (staff / back-office authorization)
        ability_class: 'Spree::Ability',

        # reporting (see docs/plans/6.0-analytics-semantic-layer.md)
        reporting_adapter: 'Spree::Reporting::Adapters::Live',

        # storefront record access (ownership + guest tokens); the B2B seam —
        # see Spree::Storefront::AccessPolicy
        storefront_access_policy_class: 'Spree::Storefront::AccessPolicy',

        # cart — the legacy Spree::Cart::* namespace is gone (Spree::Cart is the
        # cart model since 6.0); surviving services live under Spree::Carts::.
        # cart_create/update/estimate_shipping_rates/change_currency service
        # registrations were removed with their dead implementations.
        cart_compare_line_items_service: 'Spree::CompareLineItems',
        cart_add_item_workflow: 'Spree::Carts::AddItem',
        cart_recalculate_workflow: 'Spree::Carts::Recalculate',
        cart_recalculate_totals_workflow: 'Spree::Carts::RecalculateTotals',
        order_recalculate_totals_workflow: 'Spree::Orders::RecalculateTotals',
        cart_remove_item_service: 'Spree::Carts::RemoveItem',
        # Deprecated shims, not the workflow: they still speak the old
        # line_item:/quantity: vocabulary and delegate to
        # cart_upsert_items_workflow internally. Pointing these at the
        # workflow would ArgumentError on every legacy caller.
        cart_remove_line_item_service: 'Spree::Carts::RemoveLineItem',
        cart_set_item_quantity_service: 'Spree::Carts::SetQuantity',

        # draft orders (admin item editing) — cart twins split so the two
        # sides can diverge; see Spree::Orders::AddItem
        order_add_item_service: 'Spree::Orders::AddItem',
        order_update_item_service: 'Spree::Orders::UpdateItem',
        order_remove_line_item_service: 'Spree::Orders::RemoveLineItem',
        order_remove_item_service: 'Spree::Orders::RemoveItem',
        cart_empty_service: 'Spree::Carts::Empty',
        cart_destroy_service: 'Spree::Carts::Destroy',
        cart_associate_service: 'Spree::Carts::Associate',
        cart_remove_out_of_stock_items_service: 'Spree::Carts::RemoveOutOfStockItems',

        # carts
        carts_complete_workflow: 'Spree::Carts::Complete',
        carts_create_service: 'Spree::Carts::Create',
        carts_update_service: 'Spree::Carts::Update',
        cart_upsert_items_workflow: 'Spree::Carts::UpsertItems',
        order_upsert_items_workflow: 'Spree::Orders::UpsertItems',
        cart_merge_workflow: 'Spree::Carts::Merge',

        # checkout
        checkout_advance_service: 'Spree::Checkout::Advance',
        store_credit_apply_service: 'Spree::StoreCredits::Apply',
        store_credit_remove_service: 'Spree::StoreCredits::Remove',

        # gift cards
        gift_card_apply_workflow: 'Spree::GiftCards::Apply',
        gift_card_remove_workflow: 'Spree::GiftCards::Remove',
        gift_card_redeem_workflow: 'Spree::GiftCards::Redeem',
        gift_card_cancel_workflow: 'Spree::GiftCards::Cancel',

        # order
        order_approve_service: 'Spree::Orders::Approve',
        order_cancel_workflow: 'Spree::Orders::Cancel',
        order_complete_workflow: 'Spree::Orders::Complete',
        order_discount_create_service: 'Spree::Orders::Discounts::Create',
        order_discount_update_service: 'Spree::Orders::Discounts::Update',
        order_discount_destroy_service: 'Spree::Orders::Discounts::Destroy',
        order_fee_create_service: 'Spree::Orders::Fees::Create',
        order_fee_update_service: 'Spree::Orders::Fees::Update',
        order_fee_destroy_service: 'Spree::Orders::Fees::Destroy',
        order_create_service: 'Spree::Orders::Create',
        order_create_from_cart_service: 'Spree::Orders::CreateFromCart',
        order_update_service: 'Spree::Orders::Update',
        order_update_statuses_service: 'Spree::Orders::UpdateStatuses',
        order_updater: 'Spree::OrderUpdater',

        # fulfillment
        fulfillment_create_workflow: 'Spree::Fulfillments::Create',
        fulfillment_update_workflow: 'Spree::Fulfillments::Update',
        fulfillment_fulfill_workflow: 'Spree::Fulfillments::Fulfill',
        fulfillment_cancel_workflow: 'Spree::Fulfillments::Cancel',
        fulfillment_mark_delivered_workflow: 'Spree::Fulfillments::MarkDelivered',
        fulfillment_purchase_label_workflow: 'Spree::Fulfillments::PurchaseLabel',

        # shipping labels + deliveries
        shipping_label_purchase_workflow: 'Spree::ShippingLabels::Purchase',
        shipping_label_refund_workflow: 'Spree::ShippingLabels::Refund',
        shipping_label_record_workflow: 'Spree::ShippingLabels::Record',
        shipping_label_confirm_refund_service: 'Spree::ShippingLabels::ConfirmRefund',
        shipping_label_store_file_service: 'Spree::ShippingLabels::StoreFile',
        delivery_update_tracking_workflow: 'Spree::Deliveries::UpdateTracking',
        delivery_create_service: 'Spree::Deliveries::Create',
        delivery_upsert_primary_service: 'Spree::Deliveries::UpsertPrimary',
        fulfillment_stand_down_service: 'Spree::Fulfillments::StandDownProvider',
        fulfillment_recalculate_delivery_service: 'Spree::Fulfillments::RecalculateDelivery',
        delivery_destroy_service: 'Spree::Deliveries::Destroy',
        return_purchase_label_workflow: 'Spree::Returns::PurchaseLabel',

        # inventory operations
        stock_level_correct_service: 'Spree::StockLevels::Correct',
        stock_level_bulk_upsert_service: 'Spree::StockLevels::BulkUpsert',
        stock_level_recount_service: 'Spree::StockLevels::Recount',
        stock_transfer_create_workflow: 'Spree::StockTransfers::Create',
        stock_transfer_update_workflow: 'Spree::StockTransfers::Update',
        stock_transfer_mark_ready_workflow: 'Spree::StockTransfers::MarkReady',
        stock_transfer_mark_in_transit_workflow: 'Spree::StockTransfers::MarkInTransit',
        stock_transfer_receive_workflow: 'Spree::StockTransfers::Receive',
        stock_transfer_cancel_workflow: 'Spree::StockTransfers::Cancel',
        stock_transfer_mark_draft_workflow: 'Spree::StockTransfers::MarkDraft',
        stock_transfer_close_workflow: 'Spree::StockTransfers::Close',
        purchase_order_create_workflow: 'Spree::PurchaseOrders::Create',
        purchase_order_update_workflow: 'Spree::PurchaseOrders::Update',
        purchase_order_mark_ordered_workflow: 'Spree::PurchaseOrders::MarkOrdered',
        purchase_order_receive_workflow: 'Spree::PurchaseOrders::Receive',
        purchase_order_cancel_workflow: 'Spree::PurchaseOrders::Cancel',
        purchase_order_mark_draft_workflow: 'Spree::PurchaseOrders::MarkDraft',
        purchase_order_close_workflow: 'Spree::PurchaseOrders::Close',

        # returns
        return_create_workflow: 'Spree::Returns::Create',
        return_approve_workflow: 'Spree::Returns::Approve',
        return_receive_workflow: 'Spree::Returns::Receive',
        return_refund_workflow: 'Spree::Returns::Refund',
        return_cancel_workflow: 'Spree::Returns::Cancel',

        # exchanges
        exchange_create_workflow: 'Spree::Exchanges::Create',
        exchange_approve_workflow: 'Spree::Exchanges::Approve',
        exchange_receive_workflow: 'Spree::Exchanges::Receive',
        exchange_fulfill_workflow: 'Spree::Exchanges::Fulfill',
        exchange_cancel_workflow: 'Spree::Exchanges::Cancel',

        # claims
        claim_create_workflow: 'Spree::Claims::Create',
        claim_approve_workflow: 'Spree::Claims::Approve',
        claim_resolve_workflow: 'Spree::Claims::Resolve',
        claim_deny_workflow: 'Spree::Claims::Deny',
        claim_cancel_workflow: 'Spree::Claims::Cancel',

        # sellers
        seller_create_workflow: 'Spree::Sellers::Create',
        seller_invite_workflow: 'Spree::Sellers::Invite',
        seller_approve_workflow: 'Spree::Sellers::Approve',
        seller_suspend_workflow: 'Spree::Sellers::Suspend',
        seller_reject_workflow: 'Spree::Sellers::Reject',
        seller_start_onboarding_workflow: 'Spree::Sellers::StartOnboarding',
        seller_submit_for_review_workflow: 'Spree::Sellers::SubmitForReview',
        seller_reopen_onboarding_workflow: 'Spree::Sellers::ReopenOnboarding',
        seller_requirement_submission_create_workflow: 'Spree::SellerRequirementSubmissions::Create',
        seller_requirement_submission_accept_workflow: 'Spree::SellerRequirementSubmissions::Accept',
        seller_requirement_submission_reject_workflow: 'Spree::SellerRequirementSubmissions::Reject',
        seller_requirement_submission_waive_workflow: 'Spree::SellerRequirementSubmissions::Waive',

        # commissions — what a marketplace charges its sellers. Swappable
        # because the pricing of a marketplace's own service is exactly the
        # kind of policy an operator replaces wholesale.
        commissions_resolve_rate_service: 'Spree::Commissions::ResolveRate',
        commissions_resolve_tax_rate_service: 'Spree::Commissions::ResolveTaxRate',
        commissions_calculate_line_service: 'Spree::Commissions::CalculateLine',
        commissions_commission_order_service: 'Spree::Commissions::CommissionOrder',

        tax_exemption_certificate_verify_workflow: 'Spree::TaxExemptionCertificates::Verify',

        # customers
        customer_create_workflow: 'Spree::Customers::Create',
        customer_anonymize_workflow: 'Spree::Customers::Anonymize',
        customer_data_export_service: 'Spree::Customers::DataExport',

        # products — every server-side write path runs through these, so a
        # :validate handler sees dashboard edits, CSV imports and seeds alike
        product_create_workflow: 'Spree::Products::Create',
        product_update_workflow: 'Spree::Products::Update',
        product_destroy_workflow: 'Spree::Products::Destroy',
        product_activate_workflow: 'Spree::Products::Activate',

        # variants — every write path runs through these, so a :validate
        # handler sees a nested payload and the variants endpoint alike
        variant_create_workflow: 'Spree::Variants::Create',
        variant_update_workflow: 'Spree::Variants::Update',
        product_archive_workflow: 'Spree::Products::Archive',
        product_draft_workflow: 'Spree::Products::Draft',

        # marketplace review — a seller submits, the operator decides
        # (docs/plans/6.0-seller-product-submission.md)
        product_propose_workflow: 'Spree::Products::Propose',
        product_approve_workflow: 'Spree::Products::Approve',
        product_reject_workflow: 'Spree::Products::Reject',

        # catalogs — the agreement, written together with the price list it
        # prices through (docs/plans/6.0-catalog-agreement-rework.md)
        catalog_create_workflow: 'Spree::Catalogs::Create',
        catalog_update_workflow: 'Spree::Catalogs::Update',
        catalog_price_list_workflow: 'Spree::Catalogs::SetPriceList',
        catalog_activate_workflow: 'Spree::Catalogs::Activate',
        catalog_deactivate_workflow: 'Spree::Catalogs::Deactivate',

        # price lists
        price_list_create_workflow: 'Spree::PriceLists::Create',
        price_list_update_workflow: 'Spree::PriceLists::Update',
        price_list_activate_workflow: 'Spree::PriceLists::Activate',
        price_list_deactivate_workflow: 'Spree::PriceLists::Deactivate',

        # invitations
        invitation_accept_workflow: 'Spree::Invitations::Accept',

        # companies — both member-adding surfaces (dashboard and storefront)
        # converge on these
        company_add_member_service: 'Spree::Companies::AddMember',
        company_invitation_accept_service: 'Spree::CompanyInvitations::Accept',

        # catalog-aware product visibility for a buyer
        products_for_context_service: 'Spree::Products::ForContext',

        # imports — the CSV pipeline's steps
        import_start_mapping_workflow: 'Spree::Imports::StartMapping',
        import_complete_mapping_workflow: 'Spree::Imports::CompleteMapping',
        import_start_processing_workflow: 'Spree::Imports::StartProcessing',
        import_complete_workflow: 'Spree::Imports::Complete',
        import_retry_failed_rows_workflow: 'Spree::Imports::RetryFailedRows',

        # which of a product's variants it leads with when sellers share the
        # listing. Ranking is marketplace policy — swap this to weight seller
        # performance, delivery speed or anything else the operator sells on
        product_buy_box_service: 'Spree::Products::SelectBuyBox',

        # tracking numbers
        tracking_number_service: 'Spree::TrackingNumbers::BaseService',

        # coupons
        # TODO: we should split this service into 2 separate - Add and Remove
        coupon_handler: 'Spree::PromotionHandler::Coupon',

        # addresses
        address_create_service: 'Spree::Addresses::Create',
        address_update_service: 'Spree::Addresses::Update',

        # What checkout must collect before a purchase is placed, and before
        # it may be dispatched. The whole total here; replaced where part
        # payment is arranged (deposits, net terms).
        purchase_amount_due_at_checkout_service: 'Spree::Purchases::AmountDueAtCheckout',

        payment_create_service: 'Spree::Payments::Create',
        payment_process_workflow: 'Spree::Payments::Process',
        payment_capture_workflow: 'Spree::Payments::Capture',
        payment_void_workflow: 'Spree::Payments::Void',
        refund_create_workflow: 'Spree::Refunds::Create',
        seller_transfer_create_workflow: 'Spree::SellerTransfers::Create',
        seller_transfer_reverse_workflow: 'Spree::SellerTransfers::Reverse',
        seller_payout_sweep_workflow: 'Spree::SellerPayouts::Sweep',
        seller_payout_complete_workflow: 'Spree::SellerPayouts::Complete',
        payments_handle_webhook_workflow: 'Spree::Payments::HandleWebhook',
        payment_session_complete_workflow: 'Spree::PaymentSessions::Complete',

        # finders
        current_store_finder: 'Spree::Stores::FindDefault',
        line_item_by_variant_finder: 'Spree::LineItems::FindByVariant',

        # search — the document shape belongs to whichever indexing provider is
        # installed (spree_meilisearch registers its own), so core ships no default.
        search_product_presenter: nil,

        # tax — assembles the exemption evidence handed to the tax provider.
        # Core resolves none; swap this to read wherever certificates live.
        tax_resolve_exemptions_service: 'Spree::Tax::ResolveExemptions'
      }.freeze

      include Spree::DependenciesHelper

      # 6.0 tier rename: these seams resolve Spree::Workflow classes now.
      # The old *_service names stay settable and readable one release so
      # applications don't crash at boot — but a legacy write is stashed,
      # NOT applied to the workflow seam: a class written against the old
      # service contract is not interchangeable with the workflow the new
      # call sites consume. Reads return the stashed value (legacy code
      # calling its own class keeps working), falling back to the workflow
      # class — safe for legacy callers, whose old keyword vocabulary the
      # workflows accept through alias_argument bridges. Removed in 6.1.
      LEGACY_WORKFLOW_KEYS = {
        cart_add_item_service: :cart_add_item_workflow,
        cart_recalculate_service: :cart_recalculate_workflow,
        cart_merge_strategy: :cart_merge_workflow,
        carts_complete_service: :carts_complete_workflow,
        carts_upsert_items_service: :cart_upsert_items_workflow,
        payments_handle_webhook_service: :payments_handle_webhook_workflow,
        fulfillment_create_service: :fulfillment_create_workflow,
        order_cancel_service: :order_cancel_workflow,
        order_complete_service: :order_complete_workflow
      }.freeze

      # Same stash-don't-apply treatment for the 6.0 Shipment→Fulfillment
      # service rename: the new class speaks the fulfillment keyword
      # vocabulary (still accepting the old shipment keywords with a
      # warning), but a legacy override written against the old keywords is
      # not interchangeable with what the new call sites pass. Removed in 6.1.
      LEGACY_SERVICE_KEYS = {
        shipment_update_service: :fulfillment_update_workflow,
        fulfillment_update_service: :fulfillment_update_workflow,
        gift_card_apply_service: :gift_card_apply_workflow,
        gift_card_remove_service: :gift_card_remove_workflow,
        gift_card_redeem_service: :gift_card_redeem_workflow
      }.freeze

      # Pure renames: the class, its contract and its keyword vocabulary are
      # unchanged, so unlike LEGACY_WORKFLOW_KEYS an override written against
      # the old name IS applied — there is nothing incompatible about it.
      # Removed in 6.1.
      RENAMED_SERVICE_KEYS = {
        checkout_add_store_credit_service: :store_credit_apply_service,
        checkout_remove_store_credit_service: :store_credit_remove_service
      }.freeze

      RENAMED_SERVICE_KEYS.each do |legacy, current|
        define_method("#{legacy}=") do |value|
          Spree::Deprecation.warn(
            "Spree::Dependencies##{legacy}= is deprecated and will be removed in Spree 6.1. " \
            "Use #{current}= instead."
          )
          send("#{current}=", value)
        end

        define_method(legacy) do
          Spree::Deprecation.warn(
            "Spree::Dependencies##{legacy} is deprecated and will be removed in Spree 6.1. " \
            "Use #{current} instead."
          )
          send(current)
        end

        # Spree.<name> resolves through <name>_class, so the rename needs the
        # constantized reader too.
        define_method("#{legacy}_class") do
          Spree::Deprecation.warn(
            "Spree::Dependencies##{legacy} is deprecated and will be removed in Spree 6.1. " \
            "Use #{current} instead."
          )
          send("#{current}_class")
        end
      end

      def legacy_workflow_overrides
        @legacy_workflow_overrides ||= {}
      end

      LEGACY_WORKFLOW_KEYS.merge(LEGACY_SERVICE_KEYS).each do |legacy, current|
        define_method("#{legacy}=") do |value|
          Spree::Deprecation.warn(
            "Spree::Dependencies##{legacy}= is deprecated and NO LONGER CONSULTED by Spree — " \
            "the override was not applied. Port the class to the #{current} contract and " \
            "set #{current}= instead. The #{legacy} name is removed in Spree 6.1."
          )
          legacy_workflow_overrides[legacy] = value
        end

        define_method(legacy) do
          Spree::Deprecation.warn("Spree::Dependencies##{legacy} is deprecated and will be removed in Spree 6.1. Use #{current} instead.")
          legacy_workflow_overrides.fetch(legacy) { send(current) }
        end

        define_method("#{legacy}_class") do
          Spree::Deprecation.warn("Spree::Dependencies##{legacy} is deprecated and will be removed in Spree 6.1. Use #{current} instead.")
          if legacy_workflow_overrides.key?(legacy)
            value = legacy_workflow_overrides[legacy]
            value.is_a?(String) ? value.constantize : value
          else
            send("#{current}_class")
          end
        end
      end
    end
  end
end
