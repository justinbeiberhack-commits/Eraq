FactoryBot.define do
  factory :import, class: 'Spree::Import' do
    store { Spree::Store.default || create(:store) }
    association :user, factory: :admin_user
    type { 'Spree::Imports::Products' }

    # A marketplace seller's import. The seller is built in this import's own
    # store, since an import can only belong to the marketplace its seller
    # trades in.
    trait :for_seller do
      seller { create(:seller, store: store) }
    end

    factory :product_import, class: 'Spree::Imports::Products', parent: :import do
      type { 'Spree::Imports::Products' }
      # attachment { Rack::Test::UploadedFile.new(Spree::Core::Engine.root.join('spec', 'fixtures', 'files', 'products_import.csv'), 'text/csv') }

      after(:create) do |import|
        import.attachment.attach(
          io: File.open(Spree::Core::Engine.root.join('spec', 'fixtures', 'files', 'products_import.csv')),
          filename: 'products_import.csv',
          content_type: 'text/csv'
        )
      end
    end

    factory :product_translation_import, class: 'Spree::Imports::ProductTranslations', parent: :import do
      type { 'Spree::Imports::ProductTranslations' }

      after(:create) do |import|
        import.attachment.attach(
          io: File.open(Spree::Core::Engine.root.join('spec', 'fixtures', 'files', 'product_translations_import.csv')),
          filename: 'product_translations_import.csv',
          content_type: 'text/csv'
        )
      end
    end

    # Pass `price_list:` — the import is invalid without a list of its own store.
    factory :price_list_prices_import, class: 'Spree::Imports::PriceListPrices', parent: :import do
      type { 'Spree::Imports::PriceListPrices' }

      after(:create) do |import|
        import.attachment.attach(
          io: File.open(Spree::Core::Engine.root.join('spec', 'fixtures', 'files', 'price_list_prices_import.csv')),
          filename: 'price_list_prices_import.csv',
          content_type: 'text/csv'
        )
      end
    end

    factory :purchase_orders_import, class: 'Spree::Imports::PurchaseOrders', parent: :import do
      type { 'Spree::Imports::PurchaseOrders' }

      after(:build) do |import|
        import.attachment.attach(
          io: StringIO.new(Spree::ImportSchemas::PurchaseOrders.new.headers.join(',') + "\n"),
          filename: 'purchase_orders_import.csv',
          content_type: 'text/csv'
        )
      end
    end

    factory :customer_import, class: 'Spree::Imports::Customers', parent: :import do
      type { 'Spree::Imports::Customers' }

      after(:create) do |import|
        import.attachment.attach(
          io: File.open(Spree::Core::Engine.root.join('spec', 'fixtures', 'files', 'customers_import.csv')),
          filename: 'customers_import.csv',
          content_type: 'text/csv'
        )
      end
    end
  end
end
